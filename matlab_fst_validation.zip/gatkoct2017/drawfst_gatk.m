function drawfst_gatk
% 6 october 2017
% draws the gatk FST for chromosome 7
% p-value (run for 1,000,000) and actual FST value
delete(get(0,'children'))
load fst_test % from recalc_fst_new_gatk

%     fst_out7{1} = dum(1:end-1);
%     fst_out7{2}=L;
%     fst_out7{3}=pval;

fstval = fst_out7{1} ;
snp_pos = fst_out7{2};
pval = fst_out7{3}/1000000;
figure
subplot(2,1,1)
plot(snp_pos,fstval,'.','markersize',10)
set(gca,'ygrid','on')
ylabel('FST value')
title('NEW FST value for chrom 7')

subplot(2,1,2)
plot(snp_pos,-log10(pval),'.','markersize',10)
set(gca,'ygrid','on')
ylabel('-log_1_0(pvalue)')
title('NEW p-value for chrom 7')

load F:\AlfredII\recalc_fst_data
fstval = F1(C1==7);
snp_pos = L1(C1==7);
pval=P1(C1==7);

figure
subplot(2,1,1)
plot(snp_pos,fstval,'.r','markersize',10)
set(gca,'ygrid','on')
ylabel('FST value')
title('OLD FST value for chrom 7')

subplot(2,1,2)
plot(snp_pos,-log10(pval),'.r','markersize',10)
set(gca,'ygrid','on')
ylabel('-log_1_0(pvalue)')
set(gca,'ylim',[0 7])
title('OLD p-value for chrom 7')
