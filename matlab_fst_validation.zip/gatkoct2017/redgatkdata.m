function [D1,D2,snp,S]=redgatkdata(D1,D2,S)

if nargin == 0
    A=readtable('F:\akfred\gatkoct2017\Chrom07_GATK_GBJ08.txt','ReadVariableNames',1,'FileType','text');
    D1=table2array(A(:,8:end))';
    
    A=readtable('F:\akfred\gatkoct2017\Chrom07_GATK_GBJ14.txt','ReadVariableNames',1,'FileType','text');
    D2=table2array(A(:,8:end))';
    %a=sum(D1')==0 & sum(D2')==0;
    S=table2array(A(:,2));
    for i = 1 : numel(S)
        snp(i) = str2double(S{i}(13:end));
    end
end
write_out_genepop = 1;
if write_out_genepop == 1 && nargin >0
    % write out to SNP form
    % col ids are SNP_ID pop001_1  etc, pop002_1...    
    num_pop1 = size(D1,1);
    num_pop2 = size(D2,1);
    
    L1='test chrom 7 data';
    L2= '';
    num_of_snps=numel(S);
    for i = 1 : num_of_snps
        L2=[L2 S{i} ' ,'];
    end
    L2 = L2(1:end-2);
    SS1= cell(num_pop1,1);
    for j = 1 : num_pop1
        dum = ['pop001_' num2str(j) ', ']; % not ethere must be a space before the first allele
        for i=1: num_of_snps
            d = num2str(D1(j,i)+1);
            dum = [dum '0' d '0' d ' '];
        end
        SS1{j}=dum(1:end-1);
    end
    
    SS2= cell(num_pop2,1);
    for j = 1 : num_pop2
        dum = ['pop002_' num2str(j) ', '];
        for i=1: num_of_snps
            d = num2str(D2(j,i)+1);
            dum = [dum '0' d '0' d ' '];
        end
        SS2{j}=dum(1:end-1);
    end
    
    fileID = fopen('text.txt','w');
    fprintf(fileID,'%s\n',L1);
    fprintf(fileID,'%s\n',L2);
    fprintf(fileID,'%s\n','pop');
    for i = 1: numel(SS1)
        fprintf(fileID,'%s\n',SS1{i});
    end
    fprintf(fileID,'%s\n','pop');
    for i = 1: numel(SS2)
        fprintf(fileID,'%s\n',SS2{i});
    end
    fclose(fileID);
    D1=[];
    D2=[];
    snp=[];
    S=[];
end


