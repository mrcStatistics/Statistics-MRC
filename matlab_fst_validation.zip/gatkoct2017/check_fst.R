# code used to test matlab version of Fst calculation
library(diveRsity)
rm(list=ls()) 
# first check that annoying genecode format is OK - this will take  a few seconds
z=readGenepop(infile = 'F:/akfred/gatkoct2017/text.txt',gp=2) # This is the matlab data written to gencode format - allels written in size 2 format
# now calculate the fst values bewteen pos at each loci using diffcalc
z=diffCalc(infile = 'F:/akfred/gatkoct2017/text.txt',fst=TRUE) 
# load the matlab fst data, fst_from_matlab - created using saveR in matlab
source('F:/akfred/gatkoct2017/fst_from_matlab')
# check that are to all practicalpurposes identical
sum((F[1,1:1380]-z$std_stats$Fst[1:1380])^2)
plot(F[1,1:1380],z$std_stats$Fst[1:1380])